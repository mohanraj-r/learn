Data was downloaded from factfinder2.census.gov
psqlrc.conf is an example psqlrc startup script.  
If you are on a Unix environment rename to .psqlrc and place in your home directory.